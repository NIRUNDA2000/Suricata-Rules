# suricata-rules
suricata rules
We aggregate all regulations from various sources on the internet.